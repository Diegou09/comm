package com.ceduc.comm

data class ItemCarrito(
    val id: Long,
    val codigo: String,
    val descripcion: String,
    val precio: Double,
    var cantidad: Int
)
