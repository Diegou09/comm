package com.ceduc.comm

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var sqliteDB: SQLiteDB
    private lateinit var txtProd: TextView

    private fun obtenerProductos(): MutableList<producto> {
        return sqliteDB.obtenerProductos()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sqliteDB = SQLiteDB(this)

        val button1: ImageButton = findViewById(R.id.button1)
        val button2: ImageButton = findViewById(R.id.button2)
        val button3: ImageButton = findViewById(R.id.button3)
        val button4: ImageButton = findViewById(R.id.button4)
        val button5: Button = findViewById(R.id.button5)
        val button6: Button = findViewById(R.id.button6)
        txtProd = findViewById(R.id.txtProd)

        button1.setOnClickListener {
            val producto = producto(id = 1, codigo = "D841", descripcion = "Dron Super Epico", precio = 519990.0, cantidad = 2)
            abrirProducto(producto)
        }

        button2.setOnClickListener {
            val producto = producto(id = 2, codigo = "M932", descripcion = "Macbook Pro ", precio = 1299999.0, cantidad = 3)
            abrirProducto(producto)
        }

        button3.setOnClickListener {
            val producto = producto(id = 3, codigo = "AU456", descripcion = "Audífonos Pro Gamer RGB", precio = 29990.0, cantidad = 4)
            abrirProducto(producto)
        }

        button4.setOnClickListener {
            val producto = producto(id = 4, codigo = "V374", descripcion = "Visor VR Playstation 5 anashe", precio = 32999.0, cantidad = 1)
            abrirProducto(producto)
        }

        button5.setOnClickListener {
            abrirCarrito()
        }

        button6.setOnClickListener {
            val listaProductos = obtenerProductos()
            val listaProductosTexto = listaProductos.joinToString("\n") {
                "${it.descripcion} - ${it.precio}"
            }
            txtProd.text = listaProductosTexto
        }
    }

    private fun abrirProducto(producto: producto) {
        val intent = Intent(this, FormularioProductoActivity::class.java)
        intent.putExtra("producto", producto)
        startActivity(intent)
    }


    private fun abrirCarrito() {
        val intent = Intent(this, CarritoActivity::class.java)
        startActivity(intent)
    }
}
