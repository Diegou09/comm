package com.ceduc.comm

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class CarritoActivity : AppCompatActivity() {

    private lateinit var listaProductos: MutableList<producto>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_carrito)

        listaProductos = SQLiteDB(this).obtenerProductos()

        mostrarProductosEnCarrito()

        val btnPagar: Button = findViewById(R.id.btnPagar)

        btnPagar.setOnClickListener {
            pagarProductos()
        }
    }

    private fun mostrarProductosEnCarrito() {
        val listaProductosTexto = listaProductos.joinToString("\n") {
            "${it.descripcion} - ${it.precio}"
        }
        val txtListaProductos: TextView = findViewById(R.id.txtListaProductos)

        txtListaProductos.text = listaProductosTexto
    }

    private fun pagarProductos() {
        Toast.makeText(this, "¡Se ha pagado con éxito!", Toast.LENGTH_SHORT).show()

        limpiarCarrito()

        finish()
    }

    private fun limpiarCarrito() {
        SQLiteDB(this).limpiarCarrito()

        listaProductos.clear()

        val txtListaProductos: TextView = findViewById(R.id.txtListaProductos)
        txtListaProductos.text = ""
    }
}

