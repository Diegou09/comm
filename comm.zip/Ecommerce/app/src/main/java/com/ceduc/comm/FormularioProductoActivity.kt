package com.ceduc.comm

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class FormularioProductoActivity : AppCompatActivity() {

    private lateinit var producto: producto

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_formulario_producto)

        producto = intent.getParcelableExtra("producto") ?: producto()

        val btnAgregarAlCarrito: Button = findViewById(R.id.btnAgregarAlCarrito)

        btnAgregarAlCarrito.setOnClickListener {
            agregarAlCarrito()
        }
    }

    private fun agregarAlCarrito() {
        SQLiteDB(this).agregarProducto(producto)
        finish()
    }
}
